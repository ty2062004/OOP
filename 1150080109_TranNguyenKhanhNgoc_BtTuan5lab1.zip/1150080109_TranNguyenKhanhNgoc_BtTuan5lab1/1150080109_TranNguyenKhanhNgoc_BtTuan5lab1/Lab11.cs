﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace _1150080109_TranNguyenKhanhNgoc_BtTuan5lab1
{
    internal class Lab11
    {
        public void Run()
        {
            string filePath = "input_array.txt";

            if (!File.Exists(filePath))
            {
                Console.WriteLine("Khong tim thay file {0}", filePath);
                return;
            }

            // Đọc dữ liệu từ file
            string[] data = File.ReadAllText(filePath)
                                .Split(new[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries);
            int[] arr = Array.ConvertAll(data, int.Parse);

            // Sắp xếp tăng dần trước khi chèn (phòng trường hợp file chưa sắp xếp)
            Array.Sort(arr);

            Console.WriteLine("Mang ban dau (sau khi sap xep tang dan):");
            Console.WriteLine(string.Join(" ", arr));

            // Nhập số cần chèn
            Console.Write("\nNhap so nguyen can chen: ");
            int x = Convert.ToInt32(Console.ReadLine());

            // Tạo mảng mới dài hơn 1 phần tử
            int[] newArr = new int[arr.Length + 1];
            int i = 0, j = 0;
            bool inserted = false;

            while (i < arr.Length)
            {
                if (!inserted && x <= arr[i])
                {
                    newArr[j++] = x;
                    inserted = true;
                }
                else
                {
                    newArr[j++] = arr[i++];
                }
            }

            // Nếu số cần chèn lớn hơn tất cả phần tử thì thêm cuối mảng
            if (!inserted)
            {
                newArr[j] = x;
            }

            Console.WriteLine("\nMang sau khi chen {0}:", x);
            Console.WriteLine(string.Join(" ", newArr));
        }
    }
}
