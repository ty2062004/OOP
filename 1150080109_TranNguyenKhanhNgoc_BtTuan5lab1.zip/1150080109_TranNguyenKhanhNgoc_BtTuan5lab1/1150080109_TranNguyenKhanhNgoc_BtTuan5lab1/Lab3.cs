﻿using System;

namespace _1150080109_TranNguyenKhanhNgoc_BtTuan5lab1
{
    internal class Lab3
    {
        public void Run()
        {
            Console.Write("Nhap vao diem (0 - 10): ");
            double diem = Convert.ToDouble(Console.ReadLine());

            if (diem > 10 || diem < 0)
            {
                Console.WriteLine("Diem khong hop le!");
            }
            else if (diem >= 9)
            {
                Console.WriteLine("Xuat sac!");
            }
            else if (diem >= 8)
            {
                Console.WriteLine("Gioi!");
            }
            else if (diem >= 6.5)
            {
                Console.WriteLine("Kha!");
            }
            else if (diem >= 5)
            {
                Console.WriteLine("Trung binh!");
            }
            else if (diem >= 3.5)
            {
                Console.WriteLine("Yeu!");
            }
            else
            {
                Console.WriteLine("Kem!");
            }
        }
    }
}
