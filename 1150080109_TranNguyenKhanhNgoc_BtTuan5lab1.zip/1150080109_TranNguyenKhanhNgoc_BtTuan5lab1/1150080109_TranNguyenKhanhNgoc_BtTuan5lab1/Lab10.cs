﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _1150080109_TranNguyenKhanhNgoc_BtTuan5lab1
{
    internal class Lab10
    {
        public void Run()
        {
            string filePath = "input_array.txt";

            if (!File.Exists(filePath))
            {
                Console.WriteLine("Khong tim thay file {0}", filePath);
                return;
            }

            // Đọc dữ liệu từ file (mỗi số cách nhau bởi khoảng trắng)
            string[] data = File.ReadAllText(filePath).Split(new[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries);
            int[] arr = Array.ConvertAll(data, int.Parse);

            Console.WriteLine("Mang ban dau:");
            Console.WriteLine(string.Join(" ", arr));

            // Selection Sort
            for (int i = 0; i < arr.Length - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < arr.Length; j++)
                {
                    if (arr[j] < arr[minIndex])
                    {
                        minIndex = j;
                    }
                }

                // Hoán đổi
                int temp = arr[minIndex];
                arr[minIndex] = arr[i];
                arr[i] = temp;
            }

            Console.WriteLine("\nMang sau khi sap xep tang dan (Selection Sort):");
            Console.WriteLine(string.Join(" ", arr));
        }
    }
}
