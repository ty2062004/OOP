﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1150080109_TranNguyenKhanhNgoc_BtTuan5lab1
{
    internal class Lab7
    {
        public void Run()
        {
            // Nhập dữ liệu
            Console.Write("Nhap do dai canh a: ");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nhap do dai canh b: ");
            double b = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nhap do dai canh c: ");
            double c = Convert.ToDouble(Console.ReadLine());

            // Kiểm tra tam giác
            if (a + b > c && a + c > b && b + c > a && a > 0 && b > 0 && c > 0)
            {
                double chuVi = a + b + c;
                double p = chuVi / 2; // nửa chu vi
                double dienTich = Math.Sqrt(p * (p - a) * (p - b) * (p - c));

                Console.WriteLine("Ba canh lap thanh mot tam giac.");
                Console.WriteLine("Chu vi tam giac = {0}", chuVi);
                Console.WriteLine("Dien tich tam giac = {0}", dienTich);
            }
            else
            {
                Console.WriteLine("Ba do dai khong the lap thanh tam giac!");
            }
         
        }
    }
}
