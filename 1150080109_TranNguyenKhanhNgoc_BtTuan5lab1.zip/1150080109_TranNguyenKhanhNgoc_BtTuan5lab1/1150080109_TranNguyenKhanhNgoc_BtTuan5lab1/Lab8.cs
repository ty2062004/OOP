﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1150080109_TranNguyenKhanhNgoc_BtTuan5lab1
{
    internal class Lab8
    {
        public void Run()
        {
            // Nhập dữ liệu
            Console.Write("Nhap he so a: ");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nhap he so b: ");
            double b = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nhap he so c: ");
            double c = Convert.ToDouble(Console.ReadLine());

            // Xử lý phương trình
            if (a == 0)
            {
                // Trở thành phương trình bậc 1: bx + c = 0
                if (b == 0)
                {
                    if (c == 0)
                        Console.WriteLine("Phuong trinh co vo so nghiem.");
                    else
                        Console.WriteLine("Phuong trinh vo nghiem.");
                }
                else
                {
                    double x = -c / b;
                    Console.WriteLine("Phuong trinh co nghiem duy nhat: x = {0}", x);
                }
            }
            else
            {
                // Phương trình bậc 2
                double delta = b * b - 4 * a * c;

                if (delta < 0)
                {
                    Console.WriteLine("Phuong trinh vo nghiem.");
                }
                else if (delta == 0)
                {
                    double x = -b / (2 * a);
                    Console.WriteLine("Phuong trinh co nghiem kep: x = {0}", x);
                }
                else
                {
                    double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                    double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
                    Console.WriteLine("Phuong trinh co 2 nghiem phan biet:");
                    Console.WriteLine("x1 = {0}", x1);
                    Console.WriteLine("x2 = {0}", x2);
                }
            }
        }
    }
}
