﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1150080109_TranNguyenKhanhNgoc_BtTuan5lab1
{
    internal class Lab6
    {
        public void Run()
        {
            // Nhập dữ liệu
            Console.Write("Nhap vao chieu dai: ");
            double dai = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nhap vao chieu rong: ");
            double rong = Convert.ToDouble(Console.ReadLine());

            if (dai <= 0 || rong <= 0)
            {
                Console.WriteLine("Chieu dai va chieu rong phai la so thuc duong!");
                return;
            }

            // Tính chu vi và diện tích
            double chuVi = 2 * (dai + rong);
            double dienTich = dai * rong;

            // Xuất kết quả
            Console.WriteLine("Chu vi hinh chu nhat = {0}", chuVi);
            Console.WriteLine("Dien tich hinh chu nhat = {0}", dienTich);
        }
    }
}
