﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1150080109_TranNguyenKhanhNgoc_BtTuan5lab1
{
    internal class Lab5
    {
        public void Run()
        {
            // Nhập dữ liệu
            Console.Write("Nhap vao so nguyen n: ");
            int n = Convert.ToInt32(Console.ReadLine());

            // a) Kiểm tra chẵn lẻ
            if (n % 2 == 0)
            {
                Console.WriteLine("n la so chan");
            }
            else
            {
                Console.WriteLine("n la so le");
            }

            // b) Kiểm tra âm hay không âm
            if (n < 0)
            {
                Console.WriteLine("n la so am");
            }
            else
            {
                Console.WriteLine("n la so khong am");
            }
        }
    }
}
