﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1150080109_TranNguyenKhanhNgoc_BtTuan5lab1
{
    internal class Lab1
    {
        public int s3 { get; private set; }

        public Lab1()
        {
            Console.Write("Nhap vao so nguyen a: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nhap vao so nguyen b: ");
            int b = Convert.ToInt32(Console.ReadLine());


            int max = a;
            if (b > max) max = b;

            s3 = max; // gán giá trị cho property
        }
    }

}
