﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1150080109_TranNguyenKhanhNgoc_BtTuan5lab1
{
    internal class Lab9
    {
        public void Run()
        {
            Console.Write("Nhap so phan tu cua mang: ");
            int n = Convert.ToInt32(Console.ReadLine());

            if (n <= 0)
            {
                Console.WriteLine("So phan tu phai lon hon 0!");
                return;
            }

            int[] arr = new int[n];

            // Nhập mảng
            for (int i = 0; i < n; i++)
            {
                Console.Write("Nhap phan tu arr[{0}]: ", i);
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            // Tính tổng
            int tong = 0;
            for (int i = 0; i < n; i++)
            {
                tong += arr[i];
            }

            // Xuất kết quả
            Console.WriteLine("Tong cac phan tu trong mang = {0}", tong);
        }
    }
}
